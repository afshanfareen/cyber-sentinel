"""Shared test fixtures for Cyber Sentinel test suite."""

import os
import sys
from contextlib import contextmanager
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Ensure src/ is importable
_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
_SRC = _ROOT / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))


@pytest.fixture(scope="session")
def sample_normal_record():
    """Valid normal network flow record."""
    return {
        "timestamp": "2026-10-08T10:00:01Z",
        "source_ip": "10.0.0.10",
        "dest_ip": "10.0.0.20",
        "src_port": 54321,
        "dest_port": 443,
        "protocol": "TCP",
        "bytes": 1200,
        "packets": 10,
        "auth_status": None,
        "event_type": "flow",
    }


@pytest.fixture(scope="session")
def sample_port_scan_record():
    """Port scan pattern record."""
    return {
        "timestamp": "2026-10-08T10:00:05Z",
        "source_ip": "10.0.0.15",
        "dest_ip": "10.0.0.1",
        "src_port": 60000,
        "dest_port": 22,
        "protocol": "TCP",
        "bytes": 60,
        "packets": 1,
        "auth_status": None,
        "event_type": "flow",
    }


@pytest.fixture(scope="session")
def sample_brute_force_record():
    """Brute force authentication record."""
    return {
        "timestamp": "2026-10-08T10:00:10Z",
        "source_ip": "10.0.0.15",
        "dest_ip": "10.0.0.5",
        "src_port": 50123,
        "dest_port": 22,
        "protocol": "TCP",
        "bytes": 500,
        "packets": 4,
        "auth_status": "failure",
        "event_type": "authentication",
    }


@pytest.fixture(scope="session")
def sample_malformed_record():
    """Record with missing required fields."""
    return {
        "timestamp": "2026-10-08T10:00:20Z",
        # source_ip missing
        "dest_ip": "10.0.0.30",
        "dest_port": 80,
        "event_type": "flow",
    }


@pytest.fixture(scope="session")
def sample_invalid_ip_record():
    """Record with an invalid IP address."""
    return {
        "timestamp": "2026-10-08T10:00:30Z",
        "source_ip": "999.999.999.999",
        "dest_ip": "10.0.0.20",
        "dest_port": 443,
        "event_type": "flow",
    }


@pytest.fixture
def pipeline_fixture():
    """SentinelPipeline without pre-trained models (handles gracefully)."""
    from cyber_sentinel.detection.pipeline import SentinelPipeline
    return SentinelPipeline(db_repo=None)


@pytest.fixture
def db_fixture(tmp_path):
    """Temporary SQLite database with fully isolated engine and session factory.

    Does NOT touch module-level singletons in database.py, so test isolation
    is guaranteed even when multiple fixtures run in the same process.
    """
    db_path = tmp_path / "test_cyber_sentinel.db"
    db_url = f"sqlite:///{db_path}"

    # Build a completely local engine and session factory
    local_engine = create_engine(
        db_url,
        connect_args={"check_same_thread": False},
        echo=False,
    )
    LocalSession = sessionmaker(
        autocommit=False,
        autoflush=False,
        bind=local_engine,
    )

    # Create tables using the same Base as the main app
    from cyber_sentinel.database.models import Base
    Base.metadata.create_all(bind=local_engine)

    @contextmanager
    def local_get_session():
        session = LocalSession()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    from cyber_sentinel.database.repository import AlertRepository
    repo = AlertRepository(session_factory=local_get_session)

    yield repo

    # Cleanup: drop all tables and dispose engine
    Base.metadata.drop_all(bind=local_engine)
    local_engine.dispose()


@pytest.fixture
def api_client():
    """FastAPI TestClient that enters the lifespan context manager.

    Using 'with TestClient(app) as c' ensures the lifespan startup runs,
    which initialises _pipeline so pipeline-dependent routes return 200
    instead of 503.
    """
    from cyber_sentinel.api.main import app
    with TestClient(app) as c:
        yield c
