"""Cyber Sentinel dashboard package."""
